# Hossain Telecom

A mobile finance and recharge service platform for Bangladesh.  
Includes user registration, recharge requests, add money forms, and admin dashboard.  
Designed for GitHub Pages deployment with Google Sheets integration.