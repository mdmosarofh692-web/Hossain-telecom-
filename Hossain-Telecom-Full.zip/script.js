console.log("Hossain Telecom site loaded");

// Future form submission or dashboard logic will go here